# OfflineSkinOG 2.0.0 (source project)

Target: Minecraft Java 26.2, Fabric, Java 25.

## What this source currently implements
- `/offlineskin` and `/offlineskin gui` open an in-game skin picker.
- Multiple local 64x64 PNG skins are listed and selectable.
- `/offlineskin refresh` rescans the library.
- `/offlineskin` applies the selected local skin to the local player via a client mixin.
- Clear active skin from the GUI.
- Separate Skins and Capes tabs in the GUI.
- Import/select local 64x32 PNG capes and clear the active cape.
- Mod author: RatanOG.

## Install skins
Put standard 64x64 PNG player skins in:
`config/offlineskinog/skins/`

Open the game and run `/offlineskin`. Press **Refresh list**, then select a skin.

## Capes
Put standard 64x32 cape PNG files in `config/offlineskinog/capes/`. Open `/offlineskin`, choose the **Capes** tab, and select a cape. This version supports static capes. Animated cape frame playback is not implemented yet.

## Build
Requires JDK 25 and Gradle. Run:
`gradle build`

The GitHub Actions workflow in `.github/workflows/build.yml` builds the project and uploads the JAR as an artifact. It has not been verified against the exact Minecraft 26.2 mappings/API in this environment; fix any mapping/API errors reported by Gradle before using the JAR.

## Notes
This is a client-side local skin replacement. It does not upload skins to a server, and other players will not automatically see your local skin.
