package com.offlineskinog.mixin;
import com.offlineskinog.SkinLibrary;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
 @Inject(method="getSkin", at=@At("HEAD"), cancellable=true)
 private void offlineskinog$localSkin(CallbackInfoReturnable<PlayerSkin> cir) {
  if ((Object)this == Minecraft.getInstance().player && SkinLibrary.activeSkin() != null) cir.setReturnValue(SkinLibrary.activeSkin());
 }
}
