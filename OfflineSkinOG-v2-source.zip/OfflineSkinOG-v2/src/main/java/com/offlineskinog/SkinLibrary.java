package com.offlineskinog;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Local-only skin library. Put any 64x64 PNG in config/offlineskinog/skins/. */
public final class SkinLibrary {
    private static final Path ROOT = Path.of("config", "offlineskinog");
    private static final Path SKINS = ROOT.resolve("skins");
    private static final Path CAPES = ROOT.resolve("capes");
    private static final Identifier SKIN_ID = Identifier.fromNamespaceAndPath("offlineskinog", "selected_skin");
    private static final Identifier CAPE_ID = Identifier.fromNamespaceAndPath("offlineskinog", "selected_cape");
    private static final List<Path> skinFiles = new ArrayList<>();
    private static final List<Path> capeFiles = new ArrayList<>();
    private static PlayerSkin activeSkin;
    private static String selectedName = "";
    private static String selectedCapeName = "";
    private static ClientAsset.ResourceTexture activeCape;

    private SkinLibrary() {}
    public static void initialize() {
        try { Files.createDirectories(SKINS); Files.createDirectories(CAPES); refresh(); }
        catch (IOException e) { System.err.println("[OfflineSkinOG] " + e.getMessage()); }
    }
    public static void refresh() {
        skinFiles.clear();
        capeFiles.clear();
        try (var files = Files.list(SKINS)) {
            files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase().endsWith(".png"))
                .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).forEach(skinFiles::add);
        } catch (IOException e) { System.err.println("[OfflineSkinOG] Could not scan skins: " + e.getMessage()); }
        try (var files = Files.list(CAPES)) {
            files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase().endsWith(".png"))
                .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).forEach(capeFiles::add);
        } catch (IOException e) { System.err.println("[OfflineSkinOG] Could not scan capes: " + e.getMessage()); }
    }
    public static List<Path> skins() { return List.copyOf(skinFiles); }
    public static List<Path> capes() { return List.copyOf(capeFiles); }
    public static String selectedCapeName() { return selectedCapeName; }
    public static String selectedName() { return selectedName; }
    public static boolean apply(Path file) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || !Files.isRegularFile(file)) return false;
        try (InputStream in = Files.newInputStream(file)) {
            NativeImage image = NativeImage.read(in);
            if (image.getWidth() != 64 || image.getHeight() != 64) { image.close(); return false; }
            mc.getTextureManager().register(SKIN_ID, new DynamicTexture(image));
            activeSkin = new PlayerSkin(new ClientAsset.ResourceTexture(SKIN_ID, SKIN_ID), activeCape, null, PlayerModelType.WIDE, false);
            selectedName = file.getFileName().toString();
            return true;
        } catch (IOException | RuntimeException e) {
            System.err.println("[OfflineSkinOG] Skin load failed: " + e.getMessage()); return false;
        }
    }
    public static boolean applyCape(Path file) {
        Minecraft mc = Minecraft.getInstance();
        if (mc == null || !Files.isRegularFile(file)) return false;
        try (InputStream in = Files.newInputStream(file)) {
            NativeImage image = NativeImage.read(in);
            if (image.getWidth() != 64 || image.getHeight() != 32) { image.close(); return false; }
            mc.getTextureManager().register(CAPE_ID, new DynamicTexture(image));
            activeCape = new ClientAsset.ResourceTexture(CAPE_ID, CAPE_ID);
            selectedCapeName = file.getFileName().toString();
            if (activeSkin != null) activeSkin = new PlayerSkin(new ClientAsset.ResourceTexture(SKIN_ID, SKIN_ID), activeCape, null, PlayerModelType.WIDE, false);
            return true;
        } catch (IOException | RuntimeException e) {
            System.err.println("[OfflineSkinOG] Cape load failed: " + e.getMessage()); return false;
        }
    }
    public static PlayerSkin activeSkin() { return activeSkin; }
    public static void clear() { activeSkin = null; selectedName = ""; }
    public static void clearCape() {
        activeCape = null; selectedCapeName = "";
        if (activeSkin != null) activeSkin = new PlayerSkin(new ClientAsset.ResourceTexture(SKIN_ID, SKIN_ID), null, null, PlayerModelType.WIDE, false);
    }
    public static Path skinsFolder() { return SKINS; }
    public static Path capesFolder() { return CAPES; }
}
