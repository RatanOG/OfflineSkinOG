package com.offlineskinog;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.network.chat.Component;

public final class OfflineSkinOG implements ClientModInitializer {
    @Override public void onInitializeClient() {
        SkinLibrary.initialize();
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("offlineskin")
                .executes(ctx -> { MinecraftScreen.open(); return 1; })
                .then(ClientCommandManager.literal("gui").executes(ctx -> { MinecraftScreen.open(); return 1; }))
                .then(ClientCommandManager.literal("refresh").executes(ctx -> {
                    SkinLibrary.refresh();
                    ctx.getSource().sendFeedback(Component.literal("[OfflineSkinOG] Skin list refreshed."));
                    return 1;
                }))
            )
        );
    }
}
