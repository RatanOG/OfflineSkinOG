package com.offlineskinog;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.nio.file.Path;
import java.util.List;

/** Simple in-game skin picker. Add PNG files to the skins folder, then reopen /offlineskin. */
public final class MinecraftScreen extends Screen {
    private int page;
    private boolean capeTab;
    private static final int PAGE_SIZE = 6;
    private MinecraftScreen() { super(Component.literal("OfflineSkinOG")); }
    public static void open() { Minecraft.getInstance().setScreen(new MinecraftScreen()); }

    @Override protected void init() {
        clearWidgets();
        int center = width / 2;
        addRenderableWidget(Button.builder(Component.literal("Skins"), b -> { capeTab = false; page = 0; rebuild(); }).bounds(center - 115, 38, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Capes"), b -> { capeTab = true; page = 0; rebuild(); }).bounds(center + 25, 38, 90, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Refresh"), b -> rebuild()).bounds(center - 155, 64, 75, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Open folder"), b -> copyFolder()).bounds(center - 75, 64, 100, 20).build());
        if (!capeTab) addRenderableWidget(Button.builder(Component.literal("Clear skin"), b -> { SkinLibrary.clear(); rebuild(); }).bounds(center + 30, 64, 90, 20).build());
        else addRenderableWidget(Button.builder(Component.literal("Clear cape"), b -> { SkinLibrary.clearCape(); rebuild(); }).bounds(center + 30, 64, 90, 20).build());
        List<Path> files = capeTab ? SkinLibrary.capes() : SkinLibrary.skins();
        int start = page * PAGE_SIZE;
        for (int i = start; i < Math.min(files.size(), start + PAGE_SIZE); i++) {
            Path file = files.get(i);
            int row = i - start;
            String label = file.getFileName().toString();
            if (label.equals(capeTab ? SkinLibrary.selectedCapeName() : SkinLibrary.selectedName())) label = "✓ " + label;
            addRenderableWidget(Button.builder(Component.literal(label), b -> { if (capeTab) SkinLibrary.applyCape(file); else SkinLibrary.apply(file); rebuild(); })
                .bounds(center - 120, 94 + row * 24, 240, 21).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Previous"), b -> { page = Math.max(0, page - 1); rebuild(); }).bounds(center - 120, 244, 75, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Next"), b -> { if ((page + 1) * PAGE_SIZE < files.size()) page++; rebuild(); }).bounds(center + 45, 244, 75, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(center - 40, height - 28, 80, 20).build());
    }
    private void rebuild() { SkinLibrary.refresh(); clearWidgets(); init(); }
    private void copyFolder() {
        Path folder = capeTab ? SkinLibrary.capesFolder() : SkinLibrary.skinsFolder();
        Minecraft.getInstance().keyboardHandler.setClipboard(folder.toAbsolutePath().toString());
    }
    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
        graphics.drawCenteredString(font, capeTab ? "Select a local 64x32 PNG cape" : "Select a local 64x64 PNG skin", width / 2, 27, 0xB8B8B8);
        graphics.drawCenteredString(font, capeTab ? "Folder: config/offlineskinog/capes/" : "Folder: config/offlineskinog/skins/", width / 2, height - 47, 0xAAAAAA);
        if ((capeTab ? SkinLibrary.capes() : SkinLibrary.skins()).isEmpty()) graphics.drawCenteredString(font, capeTab ? "No capes found. Add 64x32 PNG files and press Refresh." : "No skins found. Add PNG files and press Refresh list.", width / 2, 130, 0xFFCC66);
        super.render(graphics, mouseX, mouseY, delta);
    }
}
